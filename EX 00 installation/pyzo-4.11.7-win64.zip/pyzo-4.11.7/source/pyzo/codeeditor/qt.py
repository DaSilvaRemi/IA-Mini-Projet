# This is the one place where codeeditor depends on Pyzo itself
from pyzo.util.qt import QtCore, QtGui, QtWidgets  # noqa
