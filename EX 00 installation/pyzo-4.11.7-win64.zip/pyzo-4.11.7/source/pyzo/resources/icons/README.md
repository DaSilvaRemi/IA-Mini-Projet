These icons are all from the famfamfam freely available icon set (http://www.famfamfam.com/),
except the ones with the "pyzo_" prefix, which are created by us (usually based on an existing icon).
